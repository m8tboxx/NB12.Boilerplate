﻿namespace NB12.Boilerplate.BuildingBlocks.Application.Security
{
    public static class PermissionClaimTypes
    {
        public const string Permission = "permission";
    }
}
