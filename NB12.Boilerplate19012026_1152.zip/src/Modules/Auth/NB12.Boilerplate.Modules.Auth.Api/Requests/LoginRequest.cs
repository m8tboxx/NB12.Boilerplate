﻿namespace NB12.Boilerplate.Modules.Auth.Api.Requests
{
    public sealed record LoginRequest(string Email, string Password);
}
