﻿using NB12.Boilerplate.BuildingBlocks.Application.Interfaces;

namespace NB12.Boilerplate.Host.Worker.Modules
{
    public static class ModuleRegistration
    {
        public static IModuleServices[] ServiceModules() => [];
    }
}
