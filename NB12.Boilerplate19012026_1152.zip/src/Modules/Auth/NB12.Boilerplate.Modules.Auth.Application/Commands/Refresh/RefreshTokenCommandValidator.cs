﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NB12.Boilerplate.Modules.Auth.Application.Commands.Refresh
{
    internal class RefreshTokenCommandValidator
    {
    }
}
