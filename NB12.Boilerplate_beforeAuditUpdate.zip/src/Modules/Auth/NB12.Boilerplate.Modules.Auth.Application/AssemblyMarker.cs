﻿namespace NB12.Boilerplate.Modules.Auth.Application
{
    public sealed class AssemblyMarker { }
}
