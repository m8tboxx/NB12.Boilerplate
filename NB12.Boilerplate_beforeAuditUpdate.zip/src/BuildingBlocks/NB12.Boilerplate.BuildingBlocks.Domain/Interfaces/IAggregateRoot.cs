﻿namespace NB12.Boilerplate.BuildingBlocks.Domain.Interfaces
{
    public interface IAggregateRoot
    {
    }
}
