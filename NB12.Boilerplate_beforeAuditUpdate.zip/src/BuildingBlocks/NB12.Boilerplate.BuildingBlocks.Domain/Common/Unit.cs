﻿namespace NB12.Boilerplate.BuildingBlocks.Domain.Common
{
    public readonly struct Unit
    {
        public static readonly Unit Value = default;
    }
}
