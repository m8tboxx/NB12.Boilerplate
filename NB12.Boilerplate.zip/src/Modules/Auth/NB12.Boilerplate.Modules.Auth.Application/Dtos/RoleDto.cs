﻿namespace NB12.Boilerplate.Modules.Auth.Application.Dtos
{
    public sealed record RoleDto(string Id, string Name);
}
