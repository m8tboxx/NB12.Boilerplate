﻿namespace NB12.Boilerplate.Modules.Auth.Application.Security
{
    public sealed record PermissionDefinition(string Key, string DisplayName, string Description, string Module);
}
