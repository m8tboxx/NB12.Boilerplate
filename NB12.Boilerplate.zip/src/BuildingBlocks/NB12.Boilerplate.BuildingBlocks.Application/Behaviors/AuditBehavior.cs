﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NB12.Boilerplate.BuildingBlocks.Application.Behaviors
{
    internal class AuditBehavior
    {
    }
}
