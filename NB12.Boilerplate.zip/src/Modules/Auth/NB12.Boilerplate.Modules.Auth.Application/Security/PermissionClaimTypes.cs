﻿namespace NB12.Boilerplate.Modules.Auth.Application.Security
{
    public static class PermissionClaimTypes
    {
        public const string Permission = "permission";
    }
}
