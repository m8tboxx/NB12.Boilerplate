﻿namespace NB12.Boilerplate.BuildingBlocks.Application.Interfaces
{
    public interface IClock
    {
    }
}
