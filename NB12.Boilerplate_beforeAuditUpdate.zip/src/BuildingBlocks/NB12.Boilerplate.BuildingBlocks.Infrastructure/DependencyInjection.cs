﻿using Microsoft.Extensions.DependencyInjection;
using NB12.Boilerplate.BuildingBlocks.Application.Interfaces;
using NB12.Boilerplate.BuildingBlocks.Infrastructure.Auditing;
using NB12.Boilerplate.BuildingBlocks.Infrastructure.Auth;

namespace NB12.Boilerplate.BuildingBlocks.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructureBuildingBlocks(this IServiceCollection services)
        {
            services.AddHttpContextAccessor();

            // CurrentUser zentral, nicht im Auth-Modul verstecken
            services.AddScoped<ICurrentUser, CurrentUser>();

            // Audit core
            services.AddSingleton<IAuditStore, NoOpAuditStore>(); // wird vom Audit-Modul überschrieben
            services.AddScoped<IAuditContextAccessor, DefaultAuditContextAccessor>();
            services.AddScoped<AuditSaveChangesInterceptor>();

            return services;
        }
    }
}
