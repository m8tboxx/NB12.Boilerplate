﻿namespace NB12.Boilerplate.Modules.Audit.Application
{
    public sealed class AssemblyMarker { }
}
