﻿namespace NB12.Boilerplate.BuildingBlocks.Application.Auditing
{
    public enum AuditOperation
    {
        Insert = 1,
        Update = 2,
        Delete = 3
    }
}
