﻿namespace NB12.Boilerplate.BuildingBlocks.Application.Security
{
    public sealed record PermissionDefinition(string Key, string DisplayName, string Description, string Module);
}
