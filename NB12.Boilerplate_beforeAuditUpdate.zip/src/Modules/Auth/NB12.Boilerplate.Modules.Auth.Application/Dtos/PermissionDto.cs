﻿namespace NB12.Boilerplate.Modules.Auth.Application.Dtos
{
    public sealed record PermissionDto(string Key, string DisplayName, string Description, string Module);
}
